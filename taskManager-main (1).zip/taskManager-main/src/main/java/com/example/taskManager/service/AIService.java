package com.example.taskManager.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

@Service
public class AIService {

    @Value("${openai.api.key}")
    private String apiKey;

    private final HttpClient client = HttpClient.newHttpClient();

    public String askAI(String title, String description) {

        try {

            String prompt = """
You are a smart task manager assistant.

You must classify the task priority based on these strict rules:

HIGH:
- anything urgent
- anything due today or tomorrow
- exams, projects, deadlines, submissions
- anything with words like: urgent, ASAP, tonight, deadline, due

LOW:
- small personal tasks
- shopping, groceries, buying food
- cleaning, casual things, optional things

MEDIUM:
- everything else

Return ONLY valid JSON:

{
  "suggestedPriority": "HIGH or MEDIUM or LOW",
  "suggestedStatus": "TODO or IN_PROGRESS or DONE",
  "message": "Short explanation"
}

Task title: %s
Task description: %s
""".formatted(title, description);

            String requestBody = """
        {
          "model": "gpt-4",
          "messages": [
            {
              "role": "user",
              "content": "%s"
            }
          ],
          "temperature": 0.2
        }
        """.formatted(prompt.replace("\n", "\\n").replace("\"", "\\\""));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.openai.com/v1/chat/completions"))
                    .header("Authorization", "Bearer " + apiKey)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();

            HttpResponse<String> response =
                    client.send(request, HttpResponse.BodyHandlers.ofString());

            String body = response.body();

            System.out.println("===== FULL AI RESPONSE =====");
            System.out.println(body);
            // Extract the JSON inside "content"
            String search = "\"content\": \"";
            int start = body.indexOf(search);

            if (start == -1)
                return "{\"suggestedPriority\":\"MEDIUM\",\"suggestedStatus\":\"TODO\",\"message\":\"AI response not found\"}";

            start += search.length();

            int end = body.indexOf("}", start);
            String aiJson = body.substring(start, end + 1);

            aiJson = aiJson.replace("\\n", "")
                    .replace("\\\"", "\"");

            return aiJson;

        } catch (Exception e) {
            e.printStackTrace();
            return "{\"suggestedPriority\":\"MEDIUM\",\"suggestedStatus\":\"TODO\",\"message\":\"AI call failed\"}";
        }
    }
}
