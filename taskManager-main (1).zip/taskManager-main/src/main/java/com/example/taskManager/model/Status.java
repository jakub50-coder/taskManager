package com.example.taskManager.model;

public enum Status {
    TODO,
    IN_PROGRESS,
    DONE
}