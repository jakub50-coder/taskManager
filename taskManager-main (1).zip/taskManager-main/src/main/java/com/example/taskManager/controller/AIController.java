package com.example.taskManager.controller;

import com.example.taskManager.dto.AISuggestionRequest;
import com.example.taskManager.dto.AISuggestionResponse;
import com.example.taskManager.service.AIService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ai")
public class AIController {

    private final AIService aiService;

    public AIController(AIService aiService) {
        this.aiService = aiService;
    }

    @PostMapping("/suggest")
    public AISuggestionResponse suggest(@RequestBody AISuggestionRequest request) {

        String aiResult = aiService.askAI(request.getTitle(), request.getDescription());

        AISuggestionResponse response = new AISuggestionResponse();

        response.setSuggestedPriority(extract(aiResult, "suggestedPriority"));
        response.setSuggestedStatus(extract(aiResult, "suggestedStatus"));
        response.setMessage(extract(aiResult, "message"));

        // Prevent blank dropdown values
        if (response.getSuggestedPriority().isEmpty())
            response.setSuggestedPriority("MEDIUM");

        if (response.getSuggestedStatus().isEmpty())
            response.setSuggestedStatus("TODO");

        if (response.getMessage().isEmpty())
            response.setMessage("AI analyzed your task.");

        return response;
    }


    private String extract(String json, String key) {

        if (json == null || json.isEmpty()) return "";

        // Clean formatting issues from AI response
        json = json.replace("\\n", "")
                .replace("\n", "")
                .replace("\r", "")
                .replace("\\\"", "\"");

        String search = "\"" + key + "\":";
        int start = json.indexOf(search);

        if (start == -1) return "";

        start += search.length();

        // Skip spaces and quotes
        while (start < json.length() &&
                (json.charAt(start) == ' ' || json.charAt(start) == '\"')) {
            start++;
        }

        int end = start;

        while (end < json.length() && json.charAt(end) != '\"') {
            end++;
        }

        return json.substring(start, end).trim();
    }
}