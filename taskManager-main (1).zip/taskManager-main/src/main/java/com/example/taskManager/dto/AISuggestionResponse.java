package com.example.taskManager.dto;

public class AISuggestionResponse {

    private String suggestedPriority;
    private String suggestedStatus;
    private String message;

    // Getter for priority
    public String getSuggestedPriority() {
        return suggestedPriority;
    }

    // Setter for priority
    public void setSuggestedPriority(String suggestedPriority) {
        this.suggestedPriority = suggestedPriority;
    }

    // Getter for status
    public String getSuggestedStatus() {
        return suggestedStatus;
    }

    // Setter for status
    public void setSuggestedStatus(String suggestedStatus) {
        this.suggestedStatus = suggestedStatus;
    }

    // Getter for message
    public String getMessage() {
        return message;
    }

    // Setter for message
    public void setMessage(String message) {
        this.message = message;
    }
}