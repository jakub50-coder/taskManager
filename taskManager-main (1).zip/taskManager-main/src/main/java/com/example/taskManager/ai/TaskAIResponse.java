package com.example.taskManager.ai;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
public class TaskAIResponse {
    private String suggestedPriority;
    private String suggestedStatus;
    private String message;
}