package com.example.taskManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.awt.Desktop;
import java.net.URI;

@SpringBootApplication
public class TaskManagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(TaskManagerApplication.class, args);

        String url = "http://localhost:8080/";

        // First, try Desktop (default browser)
        if (Desktop.isDesktopSupported()) {
            try {
                Desktop.getDesktop().browse(new URI(url));
                return; // success
            } catch (Exception e) {
                System.out.println("Could not open default browser: " + e.getMessage());
            }
        }

        // Fallback: try to launch specific browsers
        try {
            String os = System.getProperty("os.name").toLowerCase();
            Process process;

            if (os.contains("win")) {
                // Windows: try Edge, then Chrome
                process = new ProcessBuilder(
                        "cmd", "/c", "start msedge " + url
                ).start();
                System.out.println("Opened Edge browser to " + url);
            } else if (os.contains("mac")) {
                // macOS: try Chrome
                process = new ProcessBuilder(
                        "open", "-a", "Google Chrome", url
                ).start();
                System.out.println("Opened Chrome browser to " + url);
            } else if (os.contains("nix") || os.contains("nux")) {
                // Linux: try Chrome
                process = new ProcessBuilder(
                        "google-chrome", url
                ).start();
                System.out.println("Opened Chrome browser to " + url);
            } else {
                System.out.println("Cannot detect OS to launch browser. Open manually: " + url);
            }
        } catch (Exception e) {
            System.out.println("Could not launch browser automatically. Open manually: " + url);
        }
    }
}