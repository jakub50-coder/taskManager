package com.example.taskManager;

import com.example.taskManager.model.Priority;
import com.example.taskManager.model.Status;
import com.example.taskManager.model.Task;
import com.example.taskManager.repository.TaskRepository;
import com.example.taskManager.service.TaskService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TaskServiceTest {

    private TaskRepository repository;
    private TaskService service;

    @BeforeEach
    void setUp() {
        repository = mock(TaskRepository.class);
        service = new TaskService(repository);
    }

    // -------- createTask() --------
    @Test
    void createTask_shouldSaveTask() {

        Task task = new Task();
        task.setTitle("Study for exam");
        task.setPriority(Priority.HIGH);
        task.setStatus(Status.TODO);
        task.setDueDate(LocalDate.now());

        when(repository.save(task)).thenReturn(task);

        Task saved = service.createTask(task);

        assertEquals("Study for exam", saved.getTitle());
        verify(repository, times(1)).save(task);
    }

    // -------- getAllTasks() --------
    @Test
    void getAllTasks_shouldReturnList() {

        when(repository.findAll()).thenReturn(List.of(new Task(), new Task()));

        List<Task> result = service.getAllTasks();

        assertEquals(2, result.size());
        verify(repository, times(1)).findAll();
    }

    // -------- getTaskById() --------
    @Test
    void getTaskById_shouldReturnTask() {

        Task task = new Task();
        task.setId(1L);

        when(repository.findById(1L)).thenReturn(Optional.of(task));

        Optional<Task> result = service.getTaskById(1L);

        assertTrue(result.isPresent());
        assertEquals(1L, result.get().getId());
        verify(repository, times(1)).findById(1L);
    }

    // -------- updateTask() --------
    @Test
    void updateTask_shouldUpdateFields() {

        Task existing = new Task();
        existing.setId(1L);

        Task updated = new Task();
        updated.setTitle("Updated title");
        updated.setPriority(Priority.MEDIUM);
        updated.setStatus(Status.IN_PROGRESS);
        updated.setDueDate(LocalDate.now());

        when(repository.findById(1L)).thenReturn(Optional.of(existing));
        when(repository.save(existing)).thenReturn(existing);

        Task result = service.updateTask(1L, updated);

        assertEquals("Updated title", result.getTitle());
        assertEquals(Priority.MEDIUM, result.getPriority());
        assertEquals(Status.IN_PROGRESS, result.getStatus());

        verify(repository, times(1)).save(existing);
    }

    // -------- deleteTask() --------
    @Test
    void deleteTask_shouldCallRepositoryDelete() {

        service.deleteTask(1L);

        verify(repository, times(1)).deleteById(1L);
    }
}