package com.example.taskManager;

import com.example.taskManager.controller.AIController;
import com.example.taskManager.dto.AISuggestionRequest;
import com.example.taskManager.dto.AISuggestionResponse;
import com.example.taskManager.service.AIService;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AIControllerTest {

    // Fake AIService
    static class FakeAIService extends AIService {
        @Override
        public String askAI(String title, String description) {
            return "{ \"suggestedPriority\": \"HIGH\", \"suggestedStatus\": \"IN_PROGRESS\", \"message\": \"Mocked AI\" }";
        }
    }

    @Test
    public void testSuggest() {

        AIService fakeService = new FakeAIService();
        AIController controller = new AIController(fakeService);

        AISuggestionRequest request = new AISuggestionRequest();
        request.setTitle("Finish project");
        request.setDescription("Due tomorrow");

        AISuggestionResponse response = controller.suggest(request);

        assertNotNull(response);
        assertEquals("HIGH", response.getSuggestedPriority());
        assertEquals("IN_PROGRESS", response.getSuggestedStatus());
        assertEquals("Mocked AI", response.getMessage()); // FIXED
    }
}