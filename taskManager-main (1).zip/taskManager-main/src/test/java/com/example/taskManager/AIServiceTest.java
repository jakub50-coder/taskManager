package com.example.taskManager;

import com.example.taskManager.service.AIService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class AIServiceTest {

    private AIService aiService;

    @BeforeEach
    void setUp() {
        aiService = new AIService();
    }

    @Test
    void testAskAIProducesJSON() {
        // Arrange
        String title = "Finish project";
        String description = "Complete the task manager project by tomorrow";

        // Act
        String response = aiService.askAI(title, description);

        // Assert
        // Check that the response contains keys we expect in the AI JSON
        assertTrue(response.contains("suggestedPriority") || response.contains("message"),
                "Response should contain 'suggestedPriority' or an error message");
        assertTrue(response.contains("suggestedStatus") || response.contains("message"),
                "Response should contain 'suggestedStatus' or an error message");
    }
}