package com.example.taskManager;

import com.example.taskManager.controller.TaskController;
import com.example.taskManager.model.Priority;
import com.example.taskManager.model.Status;
import com.example.taskManager.model.Task;
import com.example.taskManager.repository.TaskRepository;
import com.example.taskManager.service.TaskService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TaskControllerIntegrationTest {

    private TaskRepository taskRepository;
    private TaskService taskService;
    private TaskController taskController;

    @BeforeEach
    void setup() {
        // Mock the repository
        taskRepository = mock(TaskRepository.class);

        // Service and controller
        taskService = new TaskService(taskRepository);
        taskController = new TaskController(taskService);
    }

    @Test
    void createTaskEndpoint_shouldSaveTask() {
        Task task = new Task();
        task.setTitle("Integration Create Test");
        task.setPriority(Priority.MEDIUM);
        task.setStatus(Status.TODO);
        task.setDueDate(LocalDate.now());

        when(taskRepository.save(task)).thenReturn(task);

        Task savedTask = taskController.createTask(task);

        assertNotNull(savedTask);
        assertEquals("Integration Create Test", savedTask.getTitle());
        verify(taskRepository, times(1)).save(task);
    }

    @Test
    void getAllTasksEndpoint_shouldReturnTasks() {
        Task task1 = new Task();
        Task task2 = new Task();
        when(taskRepository.findAll()).thenReturn(List.of(task1, task2));

        List<Task> tasks = taskController.getAllTasks();

        assertEquals(2, tasks.size());
        verify(taskRepository, times(1)).findAll();
    }

    @Test
    void getTaskByIdEndpoint_shouldReturnTask() {
        Task task = new Task();
        task.setId(1L);

        when(taskRepository.findById(1L)).thenReturn(Optional.of(task));

        Task fetched = taskController.getTaskById(1L);

        assertNotNull(fetched);
        assertEquals(1L, fetched.getId());
        verify(taskRepository, times(1)).findById(1L);
    }

    @Test
    void updateTaskEndpoint_shouldUpdateTask() {
        Task existing = new Task();
        existing.setId(1L);

        Task updated = new Task();
        updated.setTitle("Updated Integration Task");
        updated.setPriority(Priority.HIGH);
        updated.setStatus(Status.IN_PROGRESS);
        updated.setDueDate(LocalDate.now().plusDays(1));

        when(taskRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(taskRepository.save(existing)).thenReturn(existing);

        Task result = taskController.updateTask(1L, updated);

        assertEquals("Updated Integration Task", result.getTitle());
        assertEquals(Priority.HIGH, result.getPriority());
        assertEquals(Status.IN_PROGRESS, result.getStatus());
        verify(taskRepository, times(1)).save(existing);
    }

    @Test
    void deleteTaskEndpoint_shouldCallRepositoryDelete() {
        taskController.deleteTask(1L);

        verify(taskRepository, times(1)).deleteById(1L);
    }
}